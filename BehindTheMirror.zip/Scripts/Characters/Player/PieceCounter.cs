using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PieceCounter : MonoBehaviour
{
    // Start is called before the first frame update
    public int maxPieceCount = 3;
    int currentPieceCount = 0;
    public int CurrentPieceCount { get { return currentPieceCount; } }

    private void Start()
    {
        UIDarkPieces.instance.ChangeScoreUI(currentPieceCount, maxPieceCount);
    }
    public void ImprovePieceCounter()
    {
        currentPieceCount = Mathf.Clamp(currentPieceCount + 1, 0, maxPieceCount);
        Debug.Log(currentPieceCount);
        UIDarkPieces.instance.ChangeScoreUI(currentPieceCount, maxPieceCount);
    }

}
