using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  class Interactive : MonoBehaviour
{
    public bool IsInteracted { get { return isInteracted; }  }
    private bool isInteracted = false;

    						
    // Start is called before the first frame update
    virtual protected void Interact()
    {
        isInteracted = !isInteracted;
    }

    virtual protected void Activate()
    {
        isInteracted = true;
    }
    virtual protected void Disactivate()
    {
        isInteracted = false;
    }


}
