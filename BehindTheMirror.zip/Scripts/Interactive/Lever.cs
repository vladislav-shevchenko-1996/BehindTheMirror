using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lever : Interactive
{
    Animator animator;
    public GameObject text;
    public MovablePlatform platform;
    bool canUse = false;

    private void Start()
    {
        animator = GetComponent<Animator>();

    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F) && canUse == true)
        {
            if (!IsInteracted)
            {
                Activate();
                animator.SetBool("IsUse", true);
            }
            else
            {
                Disactivate();
                animator.SetBool("IsUse", false);
            }
            platform.Use();
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        CharacterController2D target = other.GetComponent<CharacterController2D>();
        if (target.CompareTag("Player"))
        {
            text.SetActive(true);
            canUse = true;
        }
    }
    

      

   

    private void OnTriggerExit2D(Collider2D other)
    {
        CharacterController2D target = other.GetComponent<CharacterController2D>();
        if (target.CompareTag("Player"))
        {
            text.SetActive(false);
            canUse = false;
        }
    }
}
