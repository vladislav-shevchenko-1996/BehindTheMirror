using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Mirror : MonoBehaviour
{
    bool canExit = false;
    public GameObject messageUCan, messageUCannot;
    // Start is called before the first frame update
    void Start()
    {
        messageUCan.SetActive(false);
        messageUCannot.SetActive(false);
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F) && canExit)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        PieceCounter target = other.GetComponent<PieceCounter>();
        if (target!=null)
        {
            if (target.CurrentPieceCount<target.maxPieceCount)
            {
                messageUCannot.SetActive(true);
                
            }
            else
            {
                messageUCan.SetActive(true);
                canExit = true;
            }
        }
        
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        PieceCounter target = other.GetComponent<PieceCounter>();
        if (target != null)
        {
            if (target.CurrentPieceCount < target.maxPieceCount)
                messageUCannot.SetActive(false);
            else
                messageUCan.SetActive(false);
        }
    }
}
