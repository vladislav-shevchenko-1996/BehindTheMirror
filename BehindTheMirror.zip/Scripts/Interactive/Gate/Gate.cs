using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gate : MonoBehaviour
{
    bool isOpen=false;
    Collider2D colliderGate;
    Animator animator;
    // Start is called before the first frame update
    void Start()
    {
        colliderGate = GetComponent<Collider2D>();
        animator = GetComponent<Animator>();
    }

    private void FixedUpdate()
    {
        if (isOpen)
        {
            colliderGate.enabled = false;
            animator.SetBool("IsOpen", true);

        }
        else
        {
            colliderGate.enabled = true;
            animator.SetBool("IsOpen", false);
        }
    }

    // Update is called once per frame

    public void Open()
    {
        isOpen = true;
    }
    public void Close()
    {
        isOpen = false;
    }
}
