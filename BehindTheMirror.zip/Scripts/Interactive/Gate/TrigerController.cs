using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class TrigerController : Interactive
{
    // Start is called before the first frame update
    //[SerializeField]
    //List<string> targetsList=new List<string>(){"Movable"};
    //Rigidbody2D rd;
    public Animator animator;
    public Gate gate;


    private void OnTriggerEnter2D(Collider2D collision)
    {
        Rigidbody2D target = collision.GetComponent<Rigidbody2D>();
        if ((target.tag == "Player" || target.tag == "Movable")&& target.mass>5f)
        {
            Interact();
            Debug.Log(IsInteracted);
            animator.SetBool("IsPressed", true);
            gate.Open();

        }

        //Debug.Log($"In:{targetcount}");
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        Rigidbody2D target = collision.GetComponent<Rigidbody2D>();
        if (((target.tag == "Player" || target.tag == "Movable"))&& target.mass > 5f)
        {
            Interact();
            Debug.Log(IsInteracted);
            animator.SetBool("IsPressed", false);
            gate.Close();
        }
        
    }
    

}
