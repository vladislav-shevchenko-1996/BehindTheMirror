using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthCollectible : MonoBehaviour
{
    public int healPower = 2;

    // Start is called before the first frame update
    private void OnTriggerEnter2D(Collider2D other)
    {
        CharacterController2D target = other.GetComponent<CharacterController2D>();
        if (target!=null && target.CurrentHealth<target.maxHealth)
        {
            target.ChangeHealth(healPower);
            Destroy(gameObject);
        }
    }
}
