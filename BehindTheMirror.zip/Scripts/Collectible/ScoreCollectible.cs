using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreCollectible : MonoBehaviour
{
    bool isPiccked = false;

    // Start is called before the first frame update
    private void OnTriggerEnter2D(Collider2D other)
    {
        PieceCounter target = other.GetComponent<PieceCounter>();
        if (target!=null && target.tag=="Player" && isPiccked==true)
        {
            
            Destroy(gameObject);
            target.ImprovePieceCounter();

        }
        isPiccked = true;
    }
}
