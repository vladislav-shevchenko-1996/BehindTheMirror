using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovablePlatform : MonoBehaviour
{
    public Transform pos1, pos2;
    public float speed;
    public Transform startPos;
    Vector3 nextPos;
    public bool isTriggered = false;
    bool canMove = true;

    // Start is called before the first frame update

    void Start()
    {

        nextPos = startPos.position;
        if (isTriggered)
            canMove = false;
    }

    

    // Update is called once per frame
    void Update()
    {
        if (canMove)
        {
            if (transform.position == pos1.position)
                nextPos = pos2.position;
            if (transform.position == pos2.position)
                nextPos = pos1.position;
            transform.position = Vector3.MoveTowards(transform.position, nextPos, speed * Time.deltaTime);
        }
       
    }
    private void OnDrawGizmos()
    {
        Gizmos.DrawLine(pos1.position, pos2.position);
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        Rigidbody2D target = other.GetComponent<Rigidbody2D>();
        if (target.tag=="Player")
        {
            target.transform.parent = transform;
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
            Rigidbody2D target = other.GetComponent<Rigidbody2D>();
            if (target.tag == "Player")
            {
                target.transform.parent = null; ;
            }

     }
    public void Use()
    {
        canMove = !canMove;
    }


}
