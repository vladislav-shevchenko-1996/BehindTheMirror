using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AudioController : MonoBehaviour
{
    //public bool dontDestroyOnLoad = false;
    [SerializeField]
    string sceneName;
    static bool loaded;

    void Awake()
    {
        if (SceneManager.GetActiveScene().name==sceneName)
        {
            if (!loaded)
                DontDestroyOnLoad(gameObject);
            else
                Destroy(gameObject);

            loaded = true;
        }
        else loaded = false;

    }
}
