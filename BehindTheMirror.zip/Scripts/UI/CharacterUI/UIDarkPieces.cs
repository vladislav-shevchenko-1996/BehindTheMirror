using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIDarkPieces : MonoBehaviour
{
    public static UIDarkPieces instance { get; private set; }
    public Text score;
    // Start is called before the first frame update
    private void Awake()
    {
        instance = this;
    }
    void Start()
    {
        

    }
    public void ChangeScoreUI(int currentScore, int maxScore)
    {
        score.text = $"{currentScore.ToString()} / {maxScore.ToString()}";
    }

    // Update is called once per frame
    void Update()
    {

    }
}
