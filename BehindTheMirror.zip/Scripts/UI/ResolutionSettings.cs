using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.UI;

public class ResolutionSettings : MonoBehaviour
{
    public Text resolutionText;
    int index = 0;
    Resolution[] res;


    void Start()
    {
        res = Screen.resolutions.Distinct().ToArray();
        index = res.Length - 1;
        resolutionText.text = res[index].ToString().Remove(res[index].ToString().Length - 8);
        Screen.SetResolution(res[index].width, res[index].height, true);
    }

    // Update is called once per frame
    public void ToNext()
    {
        if (index<res.Length-1)
        {
            index++;
            resolutionText.text = res[index].ToString().Remove(res[index].ToString().Length-8);
            Screen.SetResolution(res[index].width, res[index].height, true);
        }
    }
    public void ToPrev()
    {
        if (index > 0 )
        {
            index--;
            resolutionText.text = res[index].ToString().Remove(res[index].ToString().Length - 8);
            Screen.SetResolution(res[index].width, res[index].height, true);

        }
    }
}
