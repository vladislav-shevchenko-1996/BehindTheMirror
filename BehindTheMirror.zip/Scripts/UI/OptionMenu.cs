using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class OptionMenu : MonoBehaviour
{

    public Text onButton;
    public Text offButton;
    public AudioMixer audioMixer;

    public void SetVolume(float volume)
    {
        audioMixer.SetFloat("volume", Mathf.Log10(volume) * 20);
    }

    public void SoundOff()
    {
        onButton.color = Color.black;
        offButton.color = Color.white;
        AudioListener.pause = true;
    }
    public void SoundOn()
    {
        onButton.color = Color.white;
        offButton.color = Color.black;
        AudioListener.pause = false;

    }
}
