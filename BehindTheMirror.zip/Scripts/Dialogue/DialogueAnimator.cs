using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueAnimator : MonoBehaviour
{
    public Animator startAnim;
    public DialoguesManager dm;
    //public DialogueTrigger dialogueTrigger;
    bool canInteract = false;
    public Dialogue dialogue;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F) && canInteract==true)
        {
            FindObjectOfType<DialoguesManager>().StartDialogue(dialogue);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {   
        if (other.CompareTag("Player"))
        {
            dm.startAnim.gameObject.SetActive(true);
            canInteract = true;
            startAnim.SetBool("StartOpen", true);
        }

    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canInteract = false;
            startAnim.SetBool("StartOpen", false);
            dm.EndDialogue();
        }
        
    }
}
